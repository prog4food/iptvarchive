# -*- coding: utf-8 -*-
# for localized messages
from . import _
from .e2m3u2bouquet import STATIC_INFO_DIC, __version__ as version
from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.Pixmap import Pixmap
from Components.Button import Button
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from enigma import getDesktop
from string import Formatter

ScreenWidth = getDesktop(0).size().width()
ScreenWidth = 'HD' if ScreenWidth and ScreenWidth >= 1920 else 'SD'

class ExtendedFormatter(Formatter):
    """An extended format string formatter

    Formatter with extended conversion symbol
    """
    def convert_field(self, value, conversion):
        """ Extend conversion symbol
        Following additional symbol has been added
        * l: convert to string and low case
        * u: convert to string and up case
        * c: capitalize string

        default are:
        * s: convert with str()
        * r: convert with repr()
        * a: convert with ascii()
        """
        if conversion == "u":
            return str(value).upper()
        elif conversion == "l":
            return str(value).lower()
        elif conversion == "c":
            return str(value) if str(value)[0].isupper() else str(value).capitalize()
        # Do the default conversion or raise error if no matching conversion found
        return super(ExtendedFormatter, self).convert_field(value, conversion)

formatter = ExtendedFormatter()


class E2m3u2b_About(Screen):

    def __init__(self, session):

        with open(resolveFilename(SCOPE_PLUGINS, 'Extensions/E2m3u2bouquet/skins/{}/'.format(ScreenWidth) +'about.xml'), 'r') as f:
            self.skin = f.read()

        self.session = session
        Screen.__init__(self, session)
        Screen.setTitle(self, "IPTV Bouquet Maker - %s" % _("About"))
        self.skinName = ['E2m3u2b_About', 'AutoBouquetsMaker_About']

        self["about"] = Label('')
        self["oealogo"] = Pixmap()
        self["actions"] = ActionMap(["SetupActions", "ColorActions", "MenuActions"],
                                    {
                                        "red": self.keyCancel,
                                        "ok": self.keyCancel,
                                        "cancel": self.keyCancel,
                                        "menu": self.keyCancel
                                    }, -2)

        self["key_red"] = Button(_('Close'))

        credit = "IPTV Bouquet Maker Plugin: ver. {}\n".format(version)
        credit += _("BoxType:") + formatter.format(" {brand} {model!c}\n", **STATIC_INFO_DIC)
        credit += _("SW version:") + formatter.format(" {distro!c} {imagever}\n\n", **STATIC_INFO_DIC)
        credit += _("Multi provider IPTV bouquet maker for Enigma2\n")
        credit += _("This plugin is free and should not be resold\n\n")
        credit += _("Plugin authors:\n")
        credit += "Doug Mackay (main developer)\n"
        credit += "Dave Sully aka suls (main developer)\n"
        credit += "— https://github.com/su1s/e2m3u2bouquet\n"
        credit += "Dorik1972 aka Pepsik (journe:)yman)\n"
        credit += "— https://github.com/pepsik-kiev/e2m3u2bouquet\n"
        self["about"].setText(credit)
        self.onFirstExecBegin.append(self.setImages)

    def setImages(self):
        self["oealogo"].instance.setPixmapFromFile(resolveFilename(SCOPE_PLUGINS, 'Extensions/E2m3u2bouquet/images/') + 'celentano.png')

    def keyCancel(self):
        self.close()

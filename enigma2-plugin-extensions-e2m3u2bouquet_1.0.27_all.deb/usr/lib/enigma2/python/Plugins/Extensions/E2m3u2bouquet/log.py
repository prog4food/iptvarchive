# logging
#
# One can simply use
# import log
# print>>log, "Some text"
# because the log unit looks enough like a file!

import sys
import threading
from .modules.six.moves import cStringIO

logfile = cStringIO()
# Need to make our operations thread-safe.
_lock = threading.Lock()

def write(data):
    with _lock:
       if logfile.tell() > 2000:
           # Do a sort of 2k round robin
          logfile.truncate(0)
          logfile.seek(0)
       logfile.write(data)
    sys.stdout.write(data)

def getvalue():
    with _lock:
       pos = logfile.tell()
       logfile.seek(0)
       head = logfile.read()
       tail = logfile.read(pos)
    return head + tail
